// ZoneVault - Main Application Script
// Handles SPA navigation, data loading, filtering, and dark mode

// Global variables
let appData = null;
const ALLOWED_ZONE_IDS = ['chandragiri', 'tirupati', 'puttur', 'srikalahasti', 'renigunta'];
const ADMIN_EMAILS = ['admin@zonevault.locsl'];
const ADMIN_PASSWORD = 'admin123'; // Default admin password
let leafletMap = null;
let baseLayers = {};
let currentBase = null;
let zoneMarkers = [];
let currentPage = 'home';
let selectedZoneId = '';
let isAuthenticated = false;
// Build API base for XAMPP localhost
const API_BASE = 'http://localhost/zonevault/api';

// Utility functions
function byId(id) { 
    return document.getElementById(id); 
}

function updateOfflineIndicator(isOffline) {
    const indicator = byId('offlineIndicator');
    if (indicator) {
        indicator.style.display = isOffline ? 'block' : 'none';
    }
}

function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'error' ? '#fed7d7' : type === 'success' ? '#c6f6d5' : '#bee3f8'};
        color: ${type === 'error' ? '#742a2a' : type === 'success' ? '#22543d' : '#2c5282'};
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Data loading and management
async function loadData() {
    try {
        console.log('🔄 Loading zone data...');
        
        // Check if we're offline and use cached data
        if (!navigator.onLine) {
            console.log('📱 Offline mode detected, using cached data...');
            const cachedData = localStorage.getItem('cachedZoneData');
            if (cachedData) {
                appData = JSON.parse(cachedData);
                console.log('✅ Using cached zone data');
                return appData;
            }
        }
        
        const response = await fetch(`zones-data.json?v=${Date.now()}`, { 
            cache: 'no-store' 
        });
        if (!response.ok) {
            console.error('❌ Response not OK:', response.status, response.statusText);
            throw new Error(`Failed to load zone data: ${response.status} ${response.statusText}`);
        }
        appData = await response.json();
        
        // Cache the data for offline use
        localStorage.setItem('cachedZoneData', JSON.stringify(appData));
        
        // merge in any locally added zones
        const customZones = JSON.parse(localStorage.getItem('customZones') || '[]');
        if (Array.isArray(appData.zones)) {
            let merged = [...appData.zones];
            if (Array.isArray(customZones) && customZones.length) {
                customZones.forEach(cz => {
                    const idx = merged.findIndex(z => z.id === cz.id);
                    if (idx >= 0) merged[idx] = cz; else merged.push(cz);
                });
            }
            appData.zones = merged.filter(z => ALLOWED_ZONE_IDS.includes(z.id) || !ALLOWED_ZONE_IDS.length);
        }
        console.log('✅ Zone data loaded successfully:', appData);
        return appData;
    } catch (error) {
        console.error('❌ Error loading zone data:', error);
        console.log('🔄 Using fallback data...');
        showFallbackData();
        return appData;
    }
}

// Fallback data if JSON fails to load
function showFallbackData() {
    console.log('🔄 Loading fallback data...');
    appData = {
        zones: [
            {
                id: "chandragiri",
                name: "Chandragiri Zone",
                icon: "📍",
                description: "Student residential area with hostels and colleges",
                address: "Near University Campus, Chandragiri Hills",
                population: "~15,000 students",
                keyAreas: ["Hostel blocks", "College campus", "Student market"],
                coordinates: { lat: 13.588, lng: 79.318 },
                emergencyContacts: [
                    {
                        name: "Chandragiri Police Station",
                        number: "+91-9876543201",
                        type: "critical",
                        icon: "🚓",
                        description: "Main police station for Chandragiri zone. Available 24/7 for emergencies."
                    },
                    {
                        name: "Chandragiri Health Center",
                        number: "+91-9876543203",
                        type: "support",
                        icon: "🏥",
                        description: "Local health center for medical emergencies."
                    }
                ],
                services: [
                    {
                        name: "Dr. Kumar's Clinic",
                        category: "clinic",
                        number: "+91-9876543210",
                        description: "General physician, open 9 AM - 9 PM",
                        verified: true
                    },
                    {
                        name: "Electric Solutions",
                        category: "electrician",
                        number: "+91-9876543211",
                        description: "24/7 electrical repairs and installations",
                        verified: true
                    },
                    {
                        name: "Quick Stitch Tailors",
                        category: "tailor",
                        number: "+91-9876543212",
                        description: "Clothing alterations and custom stitching",
                        verified: false
                    }
                ],
                alerts: [
                    "Traffic diversion near University Road 6–9 PM",
                    "Water supply maintenance on Friday 10 AM–2 PM",
                    "Power outage scheduled in Hostel Block B 2–4 PM"
                ]
            },
            {
                id: "tirupati",
                name: "Tirupati Zone",
                icon: "🕉️",
                description: "Temple city with religious tourism and commercial areas",
                address: "Tirupati City Center, Near Venkateswara Temple",
                population: "~35,000 residents",
                keyAreas: ["Temple complex", "Bus stand", "Railway station", "Hotels"],
                coordinates: { lat: 13.6288, lng: 79.4192 },
                emergencyContacts: [
                    {
                        name: "Tirupati City Police",
                        number: "+91-9876543301",
                        type: "critical",
                        icon: "🚓",
                        description: "Main police station for Tirupati city. Available 24/7."
                    },
                    {
                        name: "Temple Security",
                        number: "+91-9876543302",
                        type: "critical",
                        icon: "🛡️",
                        description: "Temple security for pilgrim safety and crowd control."
                    }
                ],
                alerts: [
                    "High pilgrim footfall expected this weekend",
                    "Railway station crowd management advisory",
                    "Heatwave alert — stay hydrated"
                ],
                services: [
                    {
                        name: "Tirupati Medical Center",
                        category: "clinic",
                        number: "+91-9876543310",
                        description: "Multi-specialty hospital with emergency care",
                        verified: true
                    },
                    {
                        name: "Temple Prasadam Counter",
                        category: "food",
                        number: "+91-9876543311",
                        description: "Sacred food distribution and booking",
                        verified: true
                    },
                    {
                        name: "Hotel Booking Service",
                        category: "hotel",
                        number: "+91-9876543312",
                        description: "Accommodation booking for pilgrims",
                        verified: true
                    }
                ]
            },
            {
                id: "srikalahasti",
                name: "Srikalahasti Zone",
                icon: "🌪️",
                description: "Ancient temple town with textile industry and heritage sites",
                address: "Srikalahasti Town, Near Panakala Narasimha Swamy Temple",
                population: "~25,000 residents",
                keyAreas: ["Temple complex", "Textile markets", "Heritage sites", "Industrial area"],
                coordinates: { lat: 13.7515, lng: 79.7036 },
                emergencyContacts: [
                    {
                        name: "Srikalahasti Police Station",
                        number: "+91-9876543401",
                        type: "critical",
                        icon: "🚓",
                        description: "Local police station serving Srikalahasti town."
                    },
                    {
                        name: "Srikalahasti Hospital",
                        number: "+91-9876543402",
                        type: "support",
                        icon: "🏥",
                        description: "Government hospital with emergency services."
                    }
                ],
                alerts: [
                    "Temple festival route changes announced",
                    "Strong winds expected in evening — secure loose items",
                    "Market hours extended till 10 PM"
                ],
                services: [
                    {
                        name: "Srikalahasti Medical Center",
                        category: "clinic",
                        number: "+91-9876543410",
                        description: "Primary healthcare center with emergency care",
                        verified: true
                    },
                    {
                        name: "Textile Market Hub",
                        category: "shopping",
                        number: "+91-9876543411",
                        description: "Wholesale and retail textile market",
                        verified: true
                    },
                    {
                        name: "Temple Darshan Services",
                        category: "tourist",
                        number: "+91-9876543412",
                        description: "Temple visit arrangements and guidance",
                        verified: true
                    }
                ]
            },
            {
                id: "puttur",
                name: "Puttur Zone",
                icon: "🌿",
                description: "Agricultural and rural development area with farming communities",
                address: "Puttur Town, Agricultural Development Zone",
                population: "~18,000 residents",
                keyAreas: ["Farming communities", "Agricultural markets", "Rural schools", "Health centers"],
                coordinates: { lat: 13.441, lng: 79.553 },
                emergencyContacts: [
                    {
                        name: "Puttur Police Station",
                        number: "+91-9876543601",
                        type: "critical",
                        icon: "🚓",
                        description: "Local police station serving Puttur and surrounding villages."
                    },
                    {
                        name: "Rural Health Center",
                        number: "+91-9876543602",
                        type: "support",
                        icon: "🏥",
                        description: "Primary healthcare center for rural communities."
                    }
                ],
                alerts: [
                    "Weekly farmers’ market on Saturday",
                    "Pest control advisory issued for fields",
                    "Road repairs near Cooperative Store"
                ],
                services: [
                    {
                        name: "Primary Health Center",
                        category: "clinic",
                        number: "+91-9876543610",
                        description: "Basic healthcare services for rural community",
                        verified: true
                    },
                    {
                        name: "Agricultural Market",
                        category: "market",
                        number: "+91-9876543611",
                        description: "Farm produce and agricultural supplies",
                        verified: true
                    },
                    {
                        name: "Seed and Fertilizer Store",
                        category: "agriculture",
                        number: "+91-9876543612",
                        description: "Agricultural inputs and farming supplies",
                        verified: true
                    }
                ]
            }
        ],
        nationalEmergencyNumbers: [
            {
                name: "Police Emergency",
                number: "100",
                type: "critical",
                icon: "🚨",
                description: "National police emergency number - Available 24/7"
            },
            {
                name: "Ambulance",
                number: "108",
                type: "critical",
                icon: "🚑",
                description: "Medical emergency ambulance service"
            },
            {
                name: "Fire Service",
                number: "101",
                type: "critical",
                icon: "🔥",
                description: "Fire department emergency response"
            },
            {
                name: "Women Helpline",
                number: "181",
                type: "support",
                icon: "👩",
                description: "24/7 women's safety helpline"
            }
        ],
        guidanceCategories: [
            {
                title: "Hidden Emergency Numbers",
                icon: "⚠️",
                items: [
                    "Railway Helpline: 139 (for train emergencies and complaints)",
                    "Cyber Crime: 1930 (for online fraud and cyber attacks)",
                    "Anti-Poison: 1800-180-5522 (for poisoning emergencies)",
                    "Senior Citizen Helpline: 14567 (elderly abuse and support)"
                ]
            },
            {
                title: "Legal Rights You Didn't Know",
                icon: "🛡️",
                items: [
                    "You can refuse to show your phone to police without a warrant",
                    "Landlords cannot enter your rented space without 24-hour notice",
                    "You have the right to record police interactions in public spaces"
                ]
            }
        ]
    };
    console.log('✅ Fallback data loaded with', appData.zones.length, 'zones');
}

// Page navigation
function showPage(pageId) {
    // Check authentication for protected pages
    const protectedPages = ['zones', 'emergency', 'services', 'guidance', 'alerts', 'map', 'admin'];
    const publicPages = ['home', 'about', 'contact', 'login', 'signup'];
    
    if (protectedPages.includes(pageId) && !isAuthenticated) {
        showNotification('Please login to access this page.', 'error');
        showPage('login');
        return;
    }
    
    // Hide all pages
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    // Show selected page
    let targetPage = document.getElementById(pageId + '-page');
    if (!targetPage && appData && Array.isArray(appData.zones)) {
        const zone = appData.zones.find(z => z.id === pageId);
        if (zone) {
            // dynamically create zone page then continue
            renderZonePage(zone);
            targetPage = document.getElementById(pageId + '-page');
        }
    }
    if (!targetPage) {
        console.error(`Page ${pageId} not found`);
        showNotification('Page not found', 'error');
        return;
    }
    targetPage.classList.add('active');
    currentPage = pageId;
    // Load page-specific content
    loadPageContent(pageId);
    
    // Update navigation active state
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Find and activate the corresponding nav link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        if (link.textContent.toLowerCase().trim() === pageId) {
            link.classList.add('active');
        }
    });
}
function renderAlertsForZone(zone) {
    const zoneNameEl = document.getElementById('alertsZoneName');
    const list = document.getElementById('alertsList');
    const empty = document.getElementById('alertsEmpty');
    if (!zoneNameEl || !list) return;
    zoneNameEl.textContent = zone?.name || '-';
    list.innerHTML = '';
    const alerts = (zone && Array.isArray(zone.alerts)) ? zone.alerts : [];
    if (!alerts.length) {
        if (empty) empty.style.display = 'block';
        return;
    }
    if (empty) empty.style.display = 'none';
    alerts.forEach(msg => {
        const li = document.createElement('li');
        li.textContent = msg;
        list.appendChild(li);
    });
}
// Load page-specific content
function loadPageContent(pageId) {
    switch (pageId) {
        case 'home':
            renderHomePage();
            break;
        case 'zones':
            renderZonesPage();
            break;
        case 'emergency':
            renderEmergencyPage();
            break;
        case 'services':
            renderServicesPage();
            break;
        case 'guidance':
            renderGuidancePage();
            break;
        case 'alerts':
            if (appData && selectedZoneId) {
                const z = appData.zones.find(zz => zz.id === selectedZoneId);
                if (z) renderAlertsForZone(z);
            }
            break;
        case 'map':
            renderMapPage();
            break;
        case 'contact':
            // Contact page is static, no dynamic content needed
            break;
        case 'login':
        case 'signup':
            // Auth pages don't need dynamic content
            break;
        case 'admin':
            // protected page (only admin emails)
            const session = JSON.parse(localStorage.getItem('sessionUser') || 'null');
            if (!session || !ADMIN_EMAILS.includes(session.email)) {
                showNotification('Please login to access Admin.', 'error');
                showPage('login');
                return;
            }
            break;
        default:
            // Check if it's a zone-specific page
            if (appData && appData.zones) {
                const zone = appData.zones.find(z => z.id === pageId);
                if (zone) {
                    renderZonePage(zone);
                }
            }
            break;
    }
}

// Render home page with zone cards
function renderHomePage() {
    console.log('🔄 Rendering home page...');
    console.log('App data:', appData);
    
    if (!appData || !appData.zones) {
        console.error('❌ No app data or zones found');
        const container = byId('home-zone-grid');
        if (container) {
            container.innerHTML = '<div class="error">No zone data available. Please check the console for errors.</div>';
        }
        return;
    }
    
    const container = byId('home-zone-grid');
    if (!container) {
        console.error('❌ Home zone grid container not found');
        return;
    }
    
    console.log('✅ Rendering', appData.zones.length, 'zones');
    
    container.innerHTML = appData.zones.map(zone => {
        const servicesCount = Array.isArray(zone.services) ? zone.services.length : 0;
        const emergencyCount = Array.isArray(zone.emergencyContacts) ? zone.emergencyContacts.length : 0;

        return `
            <div class="zone-card" onclick="onSelectZone('${zone.id}')">
                <div class="zone-name">${zone.icon || '📍'} ${zone.name || 'Unnamed Zone'}</div>
                <div class="zone-description">${zone.description || ''}</div>
                <div class="zone-stats">
                    <span>${servicesCount} Services</span>
                    <span>${emergencyCount} Emergency Contacts</span>
                </div>
            </div>
        `;
    }).join('');
    
    console.log('✅ Home page rendered successfully');
}

// Render zones page
function renderZonesPage() {
    console.log('🔄 Rendering zones page...');
    console.log('App data:', appData);
    
    if (!appData || !appData.zones) {
        console.error('❌ No app data or zones found for zones page');
        const container = byId('zones-zone-grid');
        if (container) {
            container.innerHTML = '<div class="error">No zone data available. Please check the console for errors.</div>';
        }
        return;
    }
    
    const container = byId('zones-zone-grid');
    if (!container) {
        console.error('❌ Zones zone grid container not found');
        return;
    }
    
    console.log('✅ Rendering', appData.zones.length, 'zones for zones page');
    
    container.innerHTML = appData.zones.map(zone => {
        const keyAreas = Array.isArray(zone.keyAreas) ? zone.keyAreas.join(', ') : (zone.keyAreas || '');
        const servicesCount = Array.isArray(zone.services) ? zone.services.length : 0;
        const emergencyCount = Array.isArray(zone.emergencyContacts) ? zone.emergencyContacts.length : 0;
        
        return `
            <div class="zone-card" onclick="onSelectZone('${zone.id}')">
                <div class="zone-name">${zone.icon || '📍'} ${zone.name || 'Unnamed Zone'}</div>
            <div class="zone-description">
                    <strong>Address:</strong> ${zone.address || 'N/A'}<br>
                    <strong>Population:</strong> ${zone.population || 'N/A'}<br>
                <strong>Key Areas:</strong> ${keyAreas}
            </div>
            <div class="zone-stats">
                <span>${servicesCount} Services</span>
                <span>${emergencyCount} Emergency Contacts</span>
            </div>
        </div>
        `;
    }).join('');
    
    console.log('✅ Zones page rendered successfully');
}

// Render emergency page
function renderEmergencyPage() {
    if (!appData) return;
    
    const container = byId('emergency-grid');
    if (!container) return;
    
    let emergencyContacts = [];
    
    // Add national emergency numbers
    if (appData.nationalEmergencyNumbers) {
        emergencyContacts = [...appData.nationalEmergencyNumbers];
    }
    
    // Add zone-specific emergency contacts
    if (appData.zones) {
        appData.zones.forEach(zone => {
            if (zone.emergencyContacts) {
                emergencyContacts = emergencyContacts.concat(
                    zone.emergencyContacts.map(contact => ({
                        ...contact,
                        zoneName: zone.name,
                        zoneId: zone.id
                    }))
                );
            }
        });
    }
    
    container.innerHTML = emergencyContacts.map(contact => `
        <div class="emergency-card ${contact.type || ''}" data-zone="${contact.zoneId || ''}" data-type="${contact.type || ''}">
            <div class="contact-name">${contact.icon || ''} ${contact.name || ''}</div>
            <a href="tel:${contact.number || ''}" class="contact-number">${contact.number || ''}</a>
            <div class="contact-description">${contact.description || ''}</div>
            ${contact.availability ? `<div class="contact-availability">⏰ ${contact.availability}</div>` : ''}
            ${contact.language_support ? `<div class="contact-languages">🗣️ ${contact.language_support.join(', ')}</div>` : ''}
            ${contact.zoneName ? `<div class="zone-badge">${contact.zoneName}</div>` : ''}
        </div>
    `).join('');

    // Setup filtering
    setupEmergencyFiltering();
}

// Setup emergency filtering
function setupEmergencyFiltering() {
    const zoneFilter = byId('emergencyZoneFilter');
    const typeFilter = byId('emergencyTypeFilter');
    
    if (zoneFilter) {
        zoneFilter.addEventListener('change', filterEmergencyContacts);
    }
    if (typeFilter) {
        typeFilter.addEventListener('change', filterEmergencyContacts);
    }
}

// Filter emergency contacts
function filterEmergencyContacts() {
    const zoneFilter = byId('emergencyZoneFilter');
    const typeFilter = byId('emergencyTypeFilter');
    const cards = document.querySelectorAll('.emergency-card');
    
    const selectedZone = zoneFilter ? zoneFilter.value : '';
    const selectedType = typeFilter ? typeFilter.value : '';
    
    cards.forEach(card => {
        const cardZone = card.getAttribute('data-zone');
        const cardType = card.getAttribute('data-type');
        
        const zoneMatch = !selectedZone || cardZone === selectedZone || (!cardZone && selectedZone === '');
        const typeMatch = !selectedType || cardType === selectedType;
        
        card.style.display = (zoneMatch && typeMatch) ? 'block' : 'none';
    });
}

// Render services page
function renderServicesPage() {
    if (!appData || !appData.zones) return;
    
    const container = byId('servicesGrid');
    if (!container) return;
    
    let allServices = [];
    
    // Collect all services from all zones
    appData.zones.forEach(zone => {
        if (zone.services) {
            allServices = allServices.concat(
                zone.services.map(service => ({
                    ...service,
                    zoneName: zone.name,
                    zoneId: zone.id
                }))
            );
        }
    });
    
    container.innerHTML = allServices.map(service => `
        <div class="service-card" data-category="${service.category || ''}" data-zone="${service.zoneId}" data-rating="${service.rating || 0}">
            <div class="service-name">
                ${service.name || ''}
                ${service.verified ? '<span class="verified-badge"><i class="fas fa-check"></i> Verified</span>' : ''}
            </div>
            <div class="service-category">${(service.category || '').charAt(0).toUpperCase() + (service.category || '').slice(1)}</div>
            <a href="tel:${service.number || ''}" class="contact-number">${service.number || ''}</a>
            <div class="contact-description">${service.description || ''}</div>
            ${service.address ? `<div class="service-address">📍 ${service.address}</div>` : ''}
            ${service.hours ? `<div class="service-hours">⏰ ${service.hours}</div>` : ''}
            ${service.priceRange ? `<div class="service-price">💰 ${service.priceRange}</div>` : ''}
            ${service.services ? `<div class="service-services">🔧 ${service.services.join(', ')}</div>` : ''}
            ${service.specialties ? `<div class="service-specialties">⭐ ${service.specialties.join(', ')}</div>` : ''}
            ${service.paymentMethods ? `<div class="service-payment">💳 ${service.paymentMethods.join(', ')}</div>` : ''}
            ${service.languages ? `<div class="service-languages">🗣️ ${service.languages.join(', ')}</div>` : ''}
            <div class="service-zone-badge">${service.zoneName}</div>
            ${service.rating ? `
                <div class="service-rating">
                    <div class="stars">${'★'.repeat(Math.floor(service.rating))}${'☆'.repeat(5 - Math.floor(service.rating))}</div>
                    <span class="rating-text">${service.rating}/5</span>
                </div>
            ` : ''}
        </div>
    `).join('');
    
    // Setup filtering
    setupServiceFiltering();
}

// Setup service filtering
function setupServiceFiltering() {
    const searchInput = byId('serviceSearch');
    const zoneFilter = byId('zoneFilter');
    const serviceFilter = byId('serviceFilter');
    const ratingFilter = byId('ratingFilter');
    
    if (searchInput) {
        searchInput.addEventListener('input', filterServices);
    }
    if (zoneFilter) {
        zoneFilter.addEventListener('change', filterServices);
    }
    if (serviceFilter) {
        serviceFilter.addEventListener('change', filterServices);
    }
    if (ratingFilter) {
        ratingFilter.addEventListener('change', filterServices);
    }
}

// Filter services
function filterServices() {
    const searchTerm = (byId('serviceSearch')?.value || '').toLowerCase();
    const zoneFilter = byId('zoneFilter')?.value || '';
    const serviceFilter = byId('serviceFilter')?.value || '';
    const ratingFilter = byId('ratingFilter')?.value || '';
    
    const cards = document.querySelectorAll('.service-card');
    
    cards.forEach(card => {
        const serviceName = card.querySelector('.service-name')?.textContent.toLowerCase() || '';
        const category = card.getAttribute('data-category') || '';
        const zone = card.getAttribute('data-zone') || '';
        const rating = parseFloat(card.getAttribute('data-rating')) || 0;
        
        const matchesSearch = serviceName.includes(searchTerm);
        const matchesZone = !zoneFilter || zone === zoneFilter;
        const matchesCategory = !serviceFilter || category === serviceFilter;
        const matchesRating = !ratingFilter || rating >= parseFloat(ratingFilter);
        
        card.style.display = (matchesSearch && matchesZone && matchesCategory && matchesRating) ? 'block' : 'none';
    });
}

// Render guidance page
function renderGuidancePage() {
    if (!appData || !appData.guidanceCategories) return;
    
    const container = document.querySelector('#guidance-page .section');
    if (!container) return;
    
    // Clear existing content except the title
    const title = container.querySelector('.section-title');
    container.innerHTML = '';
    if (title) {
        container.appendChild(title);
    }
    
    // Add guidance categories
    appData.guidanceCategories.forEach(category => {
        const accordion = document.createElement('div');
        accordion.className = 'guidance-accordion';
        accordion.innerHTML = `
            <div class="guidance-header" onclick="toggleGuidance(this)">
                <span><i class="fas fa-${category.icon || 'info-circle'}"></i> ${category.title}</span>
                <i class="fas fa-chevron-down"></i>
            </div>
            <div class="guidance-content">
                ${category.items.map(item => `
                    <div class="guidance-item">${item}</div>
                `).join('')}
            </div>
        `;
        container.appendChild(accordion);
    });
}

// Render map page
function renderMapPage() {
    if (!appData || !appData.zones) return;
    
    // Initialize map if not already done
    if (!leafletMap) {
        initMap();
    }
}

// Initialize map
function initMap() {
    const mapContainer = byId('map');
    if (!mapContainer || !appData || !appData.zones) return;
    
    // Initialize Leaflet map
    leafletMap = L.map('map').setView([13.6288, 79.4192], 10);
    
    // Add base layers with offline fallback
    baseLayers = {
        osm: L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { 
            maxZoom: 19,
            attribution: '© OpenStreetMap contributors'
        }),
        carto: L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}.png', { 
            maxZoom: 19,
            attribution: '© OpenStreetMap contributors, © CARTO'
        }),
        carto_dark: L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', { 
            maxZoom: 19,
            attribution: '© OpenStreetMap contributors, © CARTO'
        }),
        esri: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', { 
            maxZoom: 19,
            attribution: '© Esri'
        }),
        esri_sat: L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { 
            maxZoom: 19,
            attribution: '© Esri'
        }),
        stamen: L.tileLayer('https://stamen-tiles.a.ssl.fastly.net/toner/{z}/{x}/{y}.png', { 
            maxZoom: 19,
            attribution: '© Stamen Design'
        })
    };
    
    // Add default layer (OpenStreetMap)
    currentBase = baseLayers.osm.addTo(leafletMap);
    
    // Add offline detection and fallback
    if (!navigator.onLine) {
        showNotification('You are offline. Map tiles may not load properly.', 'info');
    }
    
    // Add zone markers
    zoneMarkers = [];
    const zoneColors = {
        chandragiri: '#e53e3e',
        tirupati: '#3182ce',
        srikalahasti: '#38a169',
        renigunta: '#d69e2e',
        puttur: '#805ad5'
    };
    appData.zones.forEach(zone => {
        if (zone.coordinates) {
            let lat, lng;
            if (Array.isArray(zone.coordinates)) {
                [lat, lng] = zone.coordinates;
            } else {
                lat = zone.coordinates.lat;
                lng = zone.coordinates.lng;
            }
            
            if (typeof lat === 'number' && typeof lng === 'number') {
                const color = zoneColors[zone.id] || '#2d3748';
                const marker = L.circleMarker([lat, lng], {
                    radius: 8,
                    color,
                    fillColor: color,
                    fillOpacity: 0.8,
                    weight: 2
                }).addTo(leafletMap).bindPopup(`
                        <b>${zone.name || 'Zone'}</b><br>
                        ${zone.address || ''}<br>
                        <small>${zone.description || ''}</small>
                    `);
                zoneMarkers.push({ zone, marker });
            }
        }
    });
    
    // Setup map controls
    setupMapControls();

    // Add legend
    const legend = L.control({ position: 'bottomright' });
    legend.onAdd = function() {
        const div = L.DomUtil.create('div', 'info legend');
        div.style.background = 'white';
        div.style.padding = '8px 10px';
        div.style.borderRadius = '8px';
        div.style.boxShadow = '0 2px 8px rgba(0,0,0,0.15)';
        const entries = [
            ['Chandragiri', '#e53e3e'],
            ['Tirupati', '#3182ce'],
            ['Srikalahasti', '#38a169'],
            ['Renigunta', '#d69e2e'],
            ['Puttur', '#805ad5']
        ];
        div.innerHTML = entries.map(([n,c]) => `<div style="display:flex;align-items:center;gap:8px;margin:4px 0;"><span style="display:inline-block;width:12px;height:12px;background:${c};border-radius:50%;"></span>${n}</div>`).join('');
        return div;
    };
    legend.addTo(leafletMap);
    
    // Add online/offline event listeners
    window.addEventListener('online', () => {
        showNotification('Connection restored. Map tiles will load normally.', 'success');
        updateOfflineIndicator(false);
    });
    
    window.addEventListener('offline', () => {
        showNotification('Connection lost. Some map features may not work.', 'error');
        updateOfflineIndicator(true);
    });
    
    // Initialize offline indicator
    updateOfflineIndicator(!navigator.onLine);
}

// Setup map controls
function setupMapControls() {
    const tileProvider = byId('tileProvider');
    const locateBtn = byId('btnLocate');
    const resetBtn = byId('btnReset');
    
    if (tileProvider) {
        tileProvider.addEventListener('change', (e) => {
            if (currentBase) {
                leafletMap.removeLayer(currentBase);
            }
            currentBase = baseLayers[e.target.value].addTo(leafletMap);
        });
    }
    
    if (locateBtn) {
        locateBtn.addEventListener('click', () => {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition((position) => {
                    leafletMap.setView([position.coords.latitude, position.coords.longitude], 15);
                });
            } else {
                showNotification('Geolocation not supported', 'error');
            }
        });
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            leafletMap.setView([13.6288, 79.4192], 10);
        });
    }
}

// Render individual zone page
function renderZonePage(zone) {
    // Create zone page if it doesn't exist
    let pageId = `${zone.id}-page`;
    let page = byId(pageId);
    
    if (!page) {
        page = document.createElement('div');
        page.id = pageId;
        page.className = 'page';
        document.body.insertBefore(page, document.querySelector('footer'));
    }
    
    const emergencyHTML = (zone.emergencyContacts || []).map(contact => `
        <div class="emergency-card ${contact.type || ''}">
            <div class="contact-name">${contact.icon || ''} ${contact.name || ''}</div>
            <a href="tel:${contact.number || ''}" class="contact-number">${contact.number || ''}</a>
            <div class="contact-description">${contact.description || ''}</div>
        </div>
    `).join('');
    
    const servicesHTML = (zone.services || []).map(service => `
        <div class="service-card" data-category="${service.category || ''}">
            <div class="service-name">
                ${service.name || ''}
                ${service.verified ? '<span class="verified-badge"><i class="fas fa-check"></i> Verified</span>' : ''}
            </div>
            <div class="service-category">${(service.category || '').charAt(0).toUpperCase() + (service.category || '').slice(1)}</div>
            <a href="tel:${service.number || ''}" class="contact-number">${service.number || ''}</a>
            <div class="contact-description">${service.description || ''}</div>
                </div>
            `).join('');

    page.innerHTML = `
            <div class="container">
                <header>
                <h1 class="logo">${zone.icon || '📍'} ${zone.name || 'Unnamed Zone'}</h1>
                <p class="subtitle">${zone.description || ''}</p>
                <div class="zone-badge">${zone.address || ''}</div>
                </header>
                <main>
                    <section class="section">
                        <h2 class="section-title"><i class="fas fa-phone-alt"></i> Local Emergency Contacts</h2>
                        <div class="emergency-grid">${emergencyHTML}</div>
                    </section>
                    <section class="section">
                        <h2 class="section-title"><i class="fas fa-store"></i> Nearby Services</h2>
                        <div class="services-grid">${servicesHTML}</div>
                    </section>
                </main>
        </div>
    `;
}

// Dark mode functionality
function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('darkMode', isDark);
    
    const toggle = document.querySelector('.dark-mode-toggle');
    if (toggle) {
        toggle.textContent = isDark ? '☀️' : '🌙';
    }
}

// Load dark mode preference
function loadDarkModePreference() {
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) {
        document.body.classList.add('dark-mode');
        const toggle = document.querySelector('.dark-mode-toggle');
        if (toggle) {
            toggle.textContent = '☀️';
        }
    }
}

// Guidance accordion functionality
function toggleGuidance(header) {
    const content = header.nextElementSibling;
    const isActive = content.classList.contains('active');
    
    // Close all other accordions
    document.querySelectorAll('.guidance-content').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelectorAll('.guidance-header').forEach(item => {
        item.classList.remove('active');
    });
    
    // Toggle current accordion
    if (!isActive) {
        content.classList.add('active');
        header.classList.add('active');
    }
}

// Authentication functions
function handleLogin(event) {
    event.preventDefault();
    const email = byId('loginEmail')?.value;
    const password = byId('loginPassword')?.value;
    if (!email || !password) {
        showNotification('Please fill in all fields.', 'error');
        return;
    }
    // Check for admin login first
    if (email === 'admin@zonevault.locsl' && password === ADMIN_PASSWORD) {
        isAuthenticated = true;
        localStorage.setItem('sessionUser', JSON.stringify({ 
            email: 'admin@zonevault.locsl', 
            zone: 'admin', 
            is_admin: true, 
            token: 'admin_token_' + Date.now() 
        }));
        const adminLink = byId('adminLink');
        const logoutLink = byId('logoutLink');
        if (adminLink) adminLink.style.display = 'inline';
        if (logoutLink) logoutLink.style.display = 'inline';
        showNotification('Admin login successful! Welcome to ZoneVault.', 'success');
        showPage('home');
        return;
    }
    
    // Regular user login
    fetch(`${API_BASE}/login.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    }).then(r => {
        if (!r.ok) {
            throw new Error(`HTTP error! status: ${r.status}`);
        }
        return r.json();
    }).then(res => {
        if (res && res.success) {
            const user = res.user;
            isAuthenticated = true;
            localStorage.setItem('sessionUser', JSON.stringify({ email: user.email, zone: user.zone, is_admin: user.is_admin, token: res.token }));
            const adminLink = byId('adminLink');
            const logoutLink = byId('logoutLink');
            const isAdmin = !!user.is_admin || ADMIN_EMAILS.includes(user.email);
            if (adminLink) adminLink.style.display = isAdmin ? 'inline' : 'none';
            if (logoutLink) logoutLink.style.display = 'inline';
            showNotification('Login successful! Welcome to ZoneVault.', 'success');
            if (user.zone) {
                selectedZoneId = user.zone;
                localStorage.setItem('selectedZoneId', selectedZoneId);
            }
            showPage('home');
        } else {
            const users = JSON.parse(localStorage.getItem('users') || '[]');
            const user = users.find(u => u.email === email && u.password === password);
            if (!user) {
                showNotification(res?.error || 'Incorrect email or password.', 'error');
                return;
            }
            isAuthenticated = true;
            localStorage.setItem('sessionUser', JSON.stringify({ email: user.email, zone: user.zone }));
            const adminLink = byId('adminLink');
            const logoutLink = byId('logoutLink');
            if (adminLink) adminLink.style.display = ADMIN_EMAILS.includes(user.email) ? 'inline' : 'none';
            if (logoutLink) logoutLink.style.display = 'inline';
            showNotification('Login successful! Welcome to ZoneVault.', 'success');
            if (user.zone) {
                selectedZoneId = user.zone;
                localStorage.setItem('selectedZoneId', selectedZoneId);
            }
            showPage('home');
        }
    }).catch((error) => {
        console.error('Login API error:', error);
        showNotification(`Network error. API not reachable: ${API_BASE}/login.php. Error: ${error.message}`, 'error');
    });
}

// Admin: add new zone, stored in localStorage and merged into runtime
function handleAddZone(event) {
    event.preventDefault();
    const session = localStorage.getItem('sessionUser');
    if (!session) {
        showNotification('Please login to use Admin.', 'error');
        return;
    }
    const id = (byId('zoneId')?.value || '').trim();
    const name = (byId('zoneName')?.value || '').trim();
    const icon = (byId('zoneIcon')?.value || '').trim() || '📍';
    const description = (byId('zoneDescription')?.value || '').trim();
    const address = (byId('zoneAddress')?.value || '').trim();
    const lat = parseFloat(byId('zoneLat')?.value);
    const lng = parseFloat(byId('zoneLng')?.value);
    const alertsStr = (byId('zoneAlerts')?.value || '').trim();
    if (!id || !name || !description || !address || Number.isNaN(lat) || Number.isNaN(lng)) {
        showNotification('Please fill all required fields.', 'error');
        return;
    }
    const newZone = {
        id,
        name,
        icon,
        description,
        address,
        coordinates: { lat, lng },
        emergencyContacts: [],
        services: [],
        alerts: alertsStr ? alertsStr.split(',').map(a => a.trim()).filter(Boolean) : []
    };
    const s = JSON.parse(session);
    fetch(`${API_BASE}/zones.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': s.email },
        body: JSON.stringify({
            id,
            name,
            icon,
            description,
            address,
            lat,
            lng,
            alerts: newZone.alerts
        })
    }).then(r => {
        if (!r.ok) {
            throw new Error(`HTTP error! status: ${r.status}`);
        }
        return r.json();
    }).then(res => {
        if (res && res.success) {
            const customZones = JSON.parse(localStorage.getItem('customZones') || '[]');
            const idx = customZones.findIndex(z => z.id === id);
            if (idx >= 0) customZones[idx] = newZone; else customZones.push(newZone);
            localStorage.setItem('customZones', JSON.stringify(customZones));
            if (appData && Array.isArray(appData.zones)) {
                const baseIdx = appData.zones.findIndex(z => z.id === id);
                if (baseIdx >= 0) appData.zones[baseIdx] = newZone; else appData.zones.push(newZone);
            }
            const selector = document.getElementById('zoneSelector');
            if (selector && appData?.zones) {
                selector.innerHTML = '<option value="">All Zones</option>' + appData.zones.map(z => `<option value="${z.id}">${z.name}</option>`).join('');
            }
            showNotification('Zone saved.', 'success');
        } else {
            showNotification(res?.error || 'Save failed', 'error');
        }
    }).catch((error) => {
        console.error('Zones API error:', error);
        const customZones = JSON.parse(localStorage.getItem('customZones') || '[]');
        const idx = customZones.findIndex(z => z.id === id);
        if (idx >= 0) customZones[idx] = newZone; else customZones.push(newZone);
        localStorage.setItem('customZones', JSON.stringify(customZones));
        if (appData && Array.isArray(appData.zones)) {
            const baseIdx = appData.zones.findIndex(z => z.id === id);
            if (baseIdx >= 0) appData.zones[baseIdx] = newZone; else appData.zones.push(newZone);
        }
        const selector = document.getElementById('zoneSelector');
        if (selector && appData?.zones) {
            selector.innerHTML = '<option value="">All Zones</option>' + appData.zones.map(z => `<option value="${z.id}">${z.name}</option>`).join('');
        }
        showNotification('Zone saved locally (offline mode).', 'success');
    });
}

function handleSignup(event) {
    event.preventDefault();
    const name = byId('signupName')?.value;
    const email = byId('signupEmail')?.value;
    const phone = byId('signupPhone')?.value;
    const password = byId('signupPassword')?.value;
    const zone = byId('signupZone')?.value;
    if (!(name && email && phone && password && zone)) {
        showNotification('Please fill in all fields.', 'error');
        return;
    }
    fetch(`${API_BASE}/signup.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, phone, password, zone })
    }).then(r => {
        if (!r.ok) {
            throw new Error(`HTTP error! status: ${r.status}`);
        }
        return r.json();
    }).then(res => {
        if (res && res.success) {
            // Auto-login after successful signup
            isAuthenticated = true;
            localStorage.setItem('sessionUser', JSON.stringify({ 
                email: email, 
                zone: zone, 
                is_admin: false, 
                token: res.token || 'user_token_' + Date.now() 
            }));
            const adminLink = byId('adminLink');
            const logoutLink = byId('logoutLink');
            if (adminLink) adminLink.style.display = 'none';
            if (logoutLink) logoutLink.style.display = 'inline';
            showNotification('Account created successfully! Welcome to ZoneVault.', 'success');
            showPage('home');
        } else {
            showNotification(res?.error || 'Signup failed', 'error');
        }
    }).catch((error) => {
        console.error('Signup API error:', error);
        const users = JSON.parse(localStorage.getItem('users') || '[]');
        if (users.some(u => u.email === email)) {
            showNotification('User already exists with this email.', 'error');
            return;
        }
        users.push({ name, email, phone, password, zone });
        localStorage.setItem('users', JSON.stringify(users));
        
        // Auto-login after successful local signup
        isAuthenticated = true;
        localStorage.setItem('sessionUser', JSON.stringify({ 
            email: email, 
            zone: zone, 
            is_admin: false, 
            token: 'user_token_' + Date.now() 
        }));
        const adminLink = byId('adminLink');
        const logoutLink = byId('logoutLink');
        if (adminLink) adminLink.style.display = 'none';
        if (logoutLink) logoutLink.style.display = 'inline';
        showNotification('Account created locally (offline mode). Welcome to ZoneVault.', 'success');
        showPage('home');
    });
}

// Contact form handler
function handleContactForm(event) {
    event.preventDefault();
    const name = byId('contactName')?.value;
    const email = byId('contactEmail')?.value;
    const phone = byId('contactPhone')?.value;
    const zone = byId('contactZone')?.value;
    const subject = byId('contactSubject')?.value;
    const message = byId('contactMessage')?.value;
    
    if (!(name && email && zone && subject && message)) {
        showNotification('Please fill in all required fields.', 'error');
        return;
    }
    
    // Store contact form data locally (since we don't have a backend for this)
    const contactData = {
        name,
        email,
        phone,
        zone,
        subject,
        message,
        timestamp: new Date().toISOString()
    };
    
    const contacts = JSON.parse(localStorage.getItem('contactMessages') || '[]');
    contacts.push(contactData);
    localStorage.setItem('contactMessages', JSON.stringify(contacts));
    
    showNotification('Thank you for your message! We will get back to you soon.', 'success');
    
    // Reset form
    event.target.reset();
}

// Logout function
function logout() {
    isAuthenticated = false;
    localStorage.removeItem('sessionUser');
    localStorage.removeItem('selectedZoneId');
    const adminLink = byId('adminLink');
    const logoutLink = byId('logoutLink');
    if (adminLink) adminLink.style.display = 'none';
    if (logoutLink) logoutLink.style.display = 'none';
    showNotification('You have been logged out successfully.', 'success');
    showPage('login');
}

// Initialize application
async function init() {
    console.log('🚀 Initializing ZoneVault...');
    
    // Load dark mode preference
    loadDarkModePreference();
    
    // Show home page first
    showPage('home');
    
    // Load data (with fallback)
    await loadData();
    // Restore selected zone
    selectedZoneId = localStorage.getItem('selectedZoneId') || '';
    // Populate zone selector
    const selector = document.getElementById('zoneSelector');
    if (selector && appData?.zones) {
        selector.innerHTML = '<option value="">All Zones</option>' + appData.zones.map(z => `<option value="${z.id}">${z.name}</option>`).join('');
        if (selectedZoneId) selector.value = selectedZoneId;
        selector.addEventListener('change', (e) => onSelectZone(e.target.value));
    }
    // Session
    const session = localStorage.getItem('sessionUser');
    if (session) {
        isAuthenticated = true;
        const s = JSON.parse(session);
        const adminLink = byId('adminLink');
        const logoutLink = byId('logoutLink');
        if (adminLink) adminLink.style.display = ADMIN_EMAILS.includes(s.email) ? 'inline' : 'none';
        if (logoutLink) logoutLink.style.display = 'inline';
        
        // If user is authenticated, show home page instead of login
        if (s.email && s.email !== 'admin@zonevault.locsl') {
            showPage('home');
        }
    } else {
        // If no session, show login page
        showPage('login');
    }
    // show current selection in context bar
    renderSelectedZoneContext();
    
    // Render home page with zones
    renderHomePage();
    
    console.log('✅ ZoneVault initialized successfully');
}

// Event listeners
document.addEventListener('DOMContentLoaded', init);

// Zone selection helpers
function onSelectZone(zoneId) {
    selectedZoneId = zoneId || '';
    localStorage.setItem('selectedZoneId', selectedZoneId);
    renderSelectedZoneContext();
    if (currentPage === 'alerts' && selectedZoneId) {
        const z = appData?.zones?.find(zz => zz.id === selectedZoneId);
        if (z) renderAlertsForZone(z);
    }
    if (selectedZoneId) {
        showPage(selectedZoneId);
    }
}

function renderSelectedZoneContext() {
    const bar = document.getElementById('zoneContextBar');
    const nameEl = document.getElementById('selectedZoneName');
    if (!bar || !nameEl) return;
    const zone = appData?.zones?.find(z => z.id === selectedZoneId);
    if (zone) {
        bar.style.display = 'block';
        nameEl.textContent = zone.name;
    } else {
        bar.style.display = 'none';
        nameEl.textContent = '-';
    }
}

// Handle navigation clicks
document.addEventListener('click', function(e) {
    const target = e.target.closest('.nav-link');
    if (target) {
        e.preventDefault();
        const raw = target.getAttribute('data-page') || target.textContent || '';
        const pageId = raw.toLowerCase().replace(/\s+/g, '').trim();
        if (pageId) showPage(pageId);
    }
});

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    .dark-mode-toggle {
        background: none;
        border: none;
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0.5rem;
        border-radius: 4px;
        transition: background-color 0.2s ease;
    }
    .dark-mode-toggle:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }
    .offline-indicator {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #f56565;
        color: white;
        padding: 0.5rem;
        text-align: center;
        z-index: 1000;
        font-size: 0.9rem;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .offline-indicator i {
        margin-right: 0.5rem;
    }
    .contact-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin: 2rem 0;
    }
    .contact-card {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .contact-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 16px rgba(0,0,0,0.15);
    }
    .contact-card h3 {
        color: #2d3748;
        margin-bottom: 1rem;
        font-size: 1.1rem;
    }
    .contact-card p {
        margin: 0.5rem 0;
        color: #4a5568;
    }
    .contact-card a {
        color: #3182ce;
        text-decoration: none;
        font-weight: 500;
    }
    .contact-card a:hover {
        text-decoration: underline;
    }
    .contact-form-section {
        margin-top: 3rem;
        padding: 2rem;
        background: #f8f9fa;
        border-radius: 12px;
        border: 1px solid #e9ecef;
    }
    .contact-form-section h2 {
        color: #2d3748;
        margin-bottom: 1.5rem;
        text-align: center;
    }
    .contact-form {
        max-width: 600px;
        margin: 0 auto;
    }
    .contact-form .form-group {
        margin-bottom: 1rem;
    }
    .contact-form label {
        display: block;
        margin-bottom: 0.5rem;
        color: #2d3748;
        font-weight: 500;
    }
    .contact-form input,
    .contact-form select,
    .contact-form textarea {
        width: 100%;
        padding: 0.75rem;
        border: 1px solid #d1d5db;
        border-radius: 8px;
        font-size: 1rem;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }
    .contact-form input:focus,
    .contact-form select:focus,
    .contact-form textarea:focus {
        outline: none;
        border-color: #3182ce;
        box-shadow: 0 0 0 3px rgba(49, 130, 206, 0.1);
    }
    .contact-form textarea {
        resize: vertical;
        min-height: 120px;
    }
`;
document.head.appendChild(style);