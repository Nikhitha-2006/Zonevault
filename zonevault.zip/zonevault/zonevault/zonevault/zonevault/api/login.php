<?php
require __DIR__ . '/db.php';
try {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $email = strtolower(trim($input['email'] ?? ''));
    $password = $input['password'] ?? '';
    if (!$email || !$password) {
        json_out(['error' => 'Missing credentials'], 400);
        exit;
    }
    $pdo = get_pdo();
    $stmt = $pdo->prepare('SELECT id, name, email, phone, password_hash, zone, is_admin FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        json_out(['error' => 'Invalid credentials'], 401);
        exit;
    }
    $token = base64_encode(random_bytes(24));
    json_out(['success' => true, 'user' => [
        'name' => $user['name'],
        'email' => $user['email'],
        'phone' => $user['phone'],
        'zone' => $user['zone'],
        'is_admin' => (bool)$user['is_admin']
    ], 'token' => $token]);
} catch (Throwable $e) {
    json_out(['error' => 'Server error'], 500);
}

