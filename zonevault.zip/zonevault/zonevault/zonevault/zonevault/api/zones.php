<?php
require __DIR__ . '/db.php';
try {
    $pdo = get_pdo();
    $pdo->exec('CREATE TABLE IF NOT EXISTS zones (
        id VARCHAR(64) PRIMARY KEY,
        name VARCHAR(190) NOT NULL,
        icon VARCHAR(8) NULL,
        description TEXT,
        address VARCHAR(255),
        lat DOUBLE,
        lng DOUBLE,
        alerts JSON NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');

    $method = $_SERVER['REQUEST_METHOD'];
    if ($method === 'GET') {
        $stmt = $pdo->query('SELECT * FROM zones');
        $rows = $stmt->fetchAll();
        foreach ($rows as &$r) {
            if (isset($r['alerts']) && $r['alerts']) {
                $r['alerts'] = json_decode($r['alerts'], true);
            } else {
                $r['alerts'] = [];
            }
        }
        json_out(['zones' => $rows]);
        exit;
    }
    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $email = strtolower(trim($_SERVER['HTTP_AUTHORIZATION'] ?? ''));
        if (!$email) { json_out(['error' => 'Unauthorized'], 401); exit; }
        $stmt = $pdo->prepare('SELECT is_admin FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $u = $stmt->fetch();
        if (!$u || !$u['is_admin']) { json_out(['error' => 'Forbidden'], 403); exit; }

        $id = trim($input['id'] ?? '');
        $name = trim($input['name'] ?? '');
        $icon = trim($input['icon'] ?? '');
        $description = trim($input['description'] ?? '');
        $address = trim($input['address'] ?? '');
        $lat = floatval($input['lat'] ?? 0);
        $lng = floatval($input['lng'] ?? 0);
        $alerts = $input['alerts'] ?? [];
        if (!$id || !$name) { json_out(['error' => 'Missing fields'], 400); exit; }
        $alertsJson = json_encode(array_values(array_filter($alerts, 'strlen')));
        $stmt = $pdo->prepare('REPLACE INTO zones (id, name, icon, description, address, lat, lng, alerts) VALUES (?,?,?,?,?,?,?,?)');
        $stmt->execute([$id, $name, $icon, $description, $address, $lat, $lng, $alertsJson]);
        json_out(['success' => true]);
        exit;
    }
    json_out(['error' => 'Method not allowed'], 405);
} catch (Throwable $e) {
    json_out(['error' => 'Server error'], 500);
}

