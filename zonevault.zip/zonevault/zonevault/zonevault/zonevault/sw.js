// ZoneVault Service Worker
const CACHE_NAME = 'zonevault-v1.0.0';
const STATIC_CACHE = 'zonevault-static-v1.0.0';
const DATA_CACHE = 'zonevault-data-v1.0.0';

const STATIC_FILES = [
    '/',
    '/zonevault.html',
    '/styles.css',
    '/script.js',
    '/manifest.json',
    '/zones-data.json'
];

self.addEventListener('install', event => {
    console.log('🔧 Service Worker installing...');
    event.waitUntil(
        caches.open(STATIC_CACHE).then(cache => {
            console.log('📦 Caching static files...');
            return cache.addAll(STATIC_FILES);
        }).then(() => {
            console.log('✅ Service Worker installed successfully');
            return self.skipWaiting();
        })
    );
});

self.addEventListener('activate', event => {
    console.log('🚀 Service Worker activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== STATIC_CACHE && cacheName !== DATA_CACHE) {
                        console.log('🗑️ Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => {
            console.log('✅ Service Worker activated');
            return self.clients.claim();
        })
    );
});

self.addEventListener('fetch', event => {
    const { request } = event;
    
    if (request.method === 'GET') {
        // Cache Leaflet/OSM tiles for offline map
        if (/\.tile\.|tile\/.+\/(?:\d+\/)\d+\/.+\.png/.test(request.url) || request.url.includes('tile.openstreetmap.org')) {
            event.respondWith(
                caches.open(DATA_CACHE).then(cache =>
                    fetch(request).then(response => {
                        if (response && response.ok) cache.put(request, response.clone());
                        return response;
                    }).catch(() => cache.match(request))
                )
            );
            return;
        }
        if (isStaticFile(request.url)) {
            event.respondWith(
                caches.match(request).then(response => {
                    if (response) {
                        return response;
                    }
                    return fetch(request).then(response => {
                        if (response.ok) {
                            const responseClone = response.clone();
                            caches.open(STATIC_CACHE).then(cache => {
                                cache.put(request, responseClone);
                            });
                        }
                        return response;
                    });
                })
            );
        }
        else if (isDataFile(request.url)) {
            event.respondWith(
                fetch(request).then(response => {
                    if (response.ok) {
                        const responseClone = response.clone();
                        caches.open(DATA_CACHE).then(cache => {
                            cache.put(request, responseClone);
                        });
                    }
                    return response;
                }).catch(() => {
                    return caches.match(request).then(response => {
                        if (response) {
                            return response;
                        }
                        return new Response(
                            JSON.stringify({ error: 'Offline' }),
                            { status: 503, headers: { 'Content-Type': 'application/json' } }
                        );
                    });
                })
            );
        }
    }
});

function isStaticFile(url) {
    return url.includes('zonevault.html') || 
           url.includes('styles.css') || 
           url.includes('script.js') ||
           url.includes('manifest.json') ||
           url === self.location.origin + '/' ||
           url === self.location.origin + '/index.html';
}

function isDataFile(url) {
    return url.includes('zones-data.json');
}

console.log('🔧 ZoneVault Service Worker loaded');
