<?php
// Update these for your XAMPP MySQL
return [
    'host' => '127.0.0.1',
    'db' => 'zonevault',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4'
];

